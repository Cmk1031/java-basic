package day05;

public class MorningTest3 {
    public static void main(String[] args) {
        int num = 10;
        System.out.println((num>0)?"양수":((num<0) ? "음수": '0'));
    }
}
