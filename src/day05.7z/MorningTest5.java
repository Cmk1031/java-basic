package day05;

public class MorningTest5 {
    public static void main(String[] args) {
        int num = 333;
        System.out.println(num - num%10 + 1);
    }
}
