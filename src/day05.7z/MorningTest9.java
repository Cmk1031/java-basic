package day05;

public class MorningTest9 {
    public static void main(String[] args) {
        char ch = 'z';
        boolean b = (65>= ch && ch<=90) || (97<=ch && 122<=ch) || (48>=ch && 57>=ch);
        System.out.println(b);

    }
}
