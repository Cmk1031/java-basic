package day05;

public class MorningTest2 {
    public static void main(String[] args) {
        int numOfApples = 123;
        int sizeofBucket = 10;
        int numOfBucket = numOfApples/sizeofBucket +1;
        System.out.println("필요한 바구니의 수: "+ numOfBucket);
    }
}
