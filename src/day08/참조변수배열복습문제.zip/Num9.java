package day08.복습;

import java.io.*;


public class Num9 {
    public static void main(String[] args) throws IOException {
        int studentNumber = 0;
        int scores[] = new int[0];
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

        while (true) {
            Menu();
            System.out.print("선택> ");
            String menuNumber = br.readLine();

            if (menuNumber.equals("5")) {
                System.out.println("프로그램 종료");
                break;
            } else if (menuNumber.equals("1")) {
                studentNumber = Case1();
            } else if (menuNumber.equals("2")) {
                scores = Case2(studentNumber);
            } else if (menuNumber.equals("3")) {
                Case3(scores);
            } else if (menuNumber.equals("4")) {
                Case4(scores);
            }
        }
    }


    private static int Case1() throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
        System.out.print("학생수> ");
        int studentNumber = Integer.parseInt(br.readLine());
        bw.write(studentNumber);
        return studentNumber;
    }

    private static int[] Case2(int studentNumber) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
        int[] scores = new int[studentNumber];
        for(int i=0; i<studentNumber; i++) {
            System.out.printf("scores[%d]>",i);
            bw.write("scores[%d]\n"+i);
            scores[i] = Integer.parseInt(br.readLine());
        }
        return scores;

    }

    private static void Case3(int[] scores) {
        for(int i=0; i<scores.length; i++) {
            System.out.printf("scores[%d]: %d\n", i, scores[i]);
        }
    }

    private static void Case4(int[] scores) {
        int max = 0;
        int sum = 0;
        for (int score : scores) {
            if(score>=max) {
                max = score;
            }
            sum+=score;
        }
        System.out.printf("최고 점수: %d\n", max);
        System.out.printf("평균 점수: %.1f\n", (double)sum/scores.length);
    }


    public static void Menu() {
        System.out.println("--------------------------------------------------------");
        System.out.println("1. 학생수 | 2. 점수입력 | 3. 점수리스트 | 4. 분석 | 5. 종료");
        System.out.println("--------------------------------------------------------");
    }
}
